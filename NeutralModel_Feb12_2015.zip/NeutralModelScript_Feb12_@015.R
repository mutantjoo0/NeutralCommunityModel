rm(list=ls())
# Load required libraries

library(car)
library(ecodist)
library(vegan)
library(VennDiagram)
library(Hmisc)

# Read Read in the OTU by sequence count matrix - shared file in mothur, the two habitats must be separated from one another i.e., all the samples belonging to "source" must be sequentially arranged one after the other and same for "target"
rS<-read.delim("BALTonsils.an.shared")

# Read in the taxonomic classification of each OTU
taxonomyFile <- read.delim("HMP.LHMP.Gastric.Cultivars.ContaminantRemoved.v35.subsample.pick.an.0.03.cons.taxonomy",colClasses="character")

# Number of OTUs detected overall - Third column of OTU by sequence count matrix
allOTUs <- seq(1,8850)

# A name for the target community and source community - this has no bearing on the calculations, necessary just for the output file names
target.comm <- c("Lungsv35")
source.comm <- c("OralWashv35")
# Title for Figures
xlabel <- c(paste("Rel. Abund. in ",source.comm))
ylabel <- c(paste("Det. Freq. in  ",target.comm))
ID1 <- c(paste("(Source)-",source.comm))
ID2 <- c(paste("(Target)-",target.comm))
ID <- c(paste(ID1,ID2,sep = "_"))
# Column names in files
file.col.name1 <- c(paste(target.comm,"Freq",sep="-"))
file.col.name2 <- c(paste(target.comm,"Abund",sep="-"))
file.col.name3 <- c(paste(source.comm,"Freq",sep="-"))
file.col.name4 <- c(paste(source.comm,"Abund",sep="-"))
file.col.name5 <- c("Col_Ind")
file.col.name6 <- c("OTU#")
file.col.name7 <-  c(paste(target.comm,"Abund.std.err",sep="-"))
file.col.name8 <-  c(paste(source.comm,"Abund.std.err",sep="-"))
file.col.name9 <- c("OTUNUmber")
file.col.name10 <- c("Taxonomy")
file.col.names <- c(file.col.name1,file.col.name2,file.col.name3,file.col.name4,file.col.name5,file.col.name6,file.col.name7,file.col.name8,file.col.name9,file.col.name10)
output.matrix <- matrix(nrow=22,ncol=1)
rownames(output.matrix) <- c("RMSE","No.OTUsintarget","No.OTUsinMouth","No.OTUsShared","No.Grey","No.Green","No.Red","SharedAbundance","UniqueAbundanceToTarget","UniqueAbundanceToSource","GreyAbundance","GreenAbundance","RedAbundance","TargetSeqs","SharedSeqs","NeutralSeqs","GreenSeqs","RedSeqs","SourceAnalyzed","SourceNeutral","SourceEnvSelFor","SourceEnvSelAgainst")

# Range of variation of the fitting parameter - Start with a broad range, make sure that the best fit Ntm falls within the range and then iteratively narrow the range to obtain the best fit Ntm
Ntm= seq(1,100,1)
# Extract the appropriate rows and columns from the OTU-by-sequence counts matrix
end <- ncol(rS)
end.row <- nrow(rS)
dS <- rS[,4:end]
if(length(which(is.na(dS))>0)) {dS <- rS[,4:(end-1)]}

#Specify which rows in the shared file correspond to the target community
targetv3v5nonsmoker=as.matrix(dS[c(1:29),])
targetSumSeqs <- colSums(targetv3v5nonsmoker)
class(targetv3v5nonsmoker) <- "numeric"

# Specify which rows in the shared file correspond to the source community

oralv3v5nonsmoker=as.matrix(dS[c(30:85),])
OralSumSeqs <- colSums(oralv3v5nonsmoker)
class(oralv3v5nonsmoker) <- "numeric"

# Calculate the detection frequency and relative abundance of each OTU in the source and target communities

targetfreqv3v5nonsmoker=c()
for (i in 1:ncol(targetv3v5nonsmoker)){
	targetfreqv3v5nonsmoker[i]=length(which(targetv3v5nonsmoker[,i]>0))/nrow(targetv3v5nonsmoker)
	}

sumseqs <- rowSums(targetv3v5nonsmoker)
for.shared.seqs <- cbind(colSums(targetv3v5nonsmoker))
target_seqs <- sum(sumseqs)

for (i in 1:nrow(targetv3v5nonsmoker)){
  
  targetv3v5nonsmoker[i,] <- targetv3v5nonsmoker[i,]/sumseqs[i]
  
  
}
	
targetabundv3v5nonsmoker=colMeans(targetv3v5nonsmoker)
targetsdv3v5nonsmoker <- c()

for (i in 1:ncol(targetv3v5nonsmoker)){
  
  targetsdv3v5nonsmoker[i] <- sd(targetv3v5nonsmoker[,i])/sqrt(nrow(targetv3v5nonsmoker)) 
  
  
}

oralfreqv3v5nonsmoker=c()
for (i in 1:ncol(oralv3v5nonsmoker)){
	oralfreqv3v5nonsmoker[i]=length(which(oralv3v5nonsmoker[,i]>0))/nrow(oralv3v5nonsmoker)
	}
sumseqs_oral <- rowSums(oralv3v5nonsmoker)
oral_seqs <- sum(sumseqs_oral)
sumseqs_oral <- rowSums(oralv3v5nonsmoker)
oral_seqs <- sum(sumseqs_oral)
Source.shared.seqs <- cbind(colSums(oralv3v5nonsmoker))
for (i in 1:nrow(oralv3v5nonsmoker)){
  
  oralv3v5nonsmoker[i,] <- oralv3v5nonsmoker[i,]/sumseqs_oral[i]
  
  
}
oralabundv3v5nonsmoker=colMeans(oralv3v5nonsmoker)

oralsdv3v5nonsmoker <- c()

for (i in 1:ncol(oralv3v5nonsmoker)){
  
  oralsdv3v5nonsmoker[i] <- sd(oralv3v5nonsmoker[,i])/sqrt(nrow(oralv3v5nonsmoker)) 
  
  
}
colind=c(1:ncol(targetv3v5nonsmoker))

v3v5_nonsmoker_neutral_data=matrix(nrow=length(targetfreqv3v5nonsmoker),ncol=8)

for (i in 1:nrow(v3v5_nonsmoker_neutral_data)){
	
	v3v5_nonsmoker_neutral_data[i,1]=targetfreqv3v5nonsmoker[i]
	v3v5_nonsmoker_neutral_data[i,2]=targetabundv3v5nonsmoker[i]
	v3v5_nonsmoker_neutral_data[i,3]=oralfreqv3v5nonsmoker[i]
	v3v5_nonsmoker_neutral_data[i,4]=oralabundv3v5nonsmoker[i]
	v3v5_nonsmoker_neutral_data[i,5]=colind[i]
	v3v5_nonsmoker_neutral_data[i,6]=allOTUs[i]
	v3v5_nonsmoker_neutral_data[i,7]=targetsdv3v5nonsmoker[i]
	v3v5_nonsmoker_neutral_data[i,8]=oralsdv3v5nonsmoker[i]
}
v3v5_nonsmoker_neutral_data_sorted=v3v5_nonsmoker_neutral_data[order(v3v5_nonsmoker_neutral_data[,4],decreasing=TRUE),]
target=length(which(v3v5_nonsmoker_neutral_data_sorted[,1]>0))
mouth=length(which(v3v5_nonsmoker_neutral_data_sorted[,3]>0))

# Determine the number of shared OTUs between the source and target communities
shared=length(which(v3v5_nonsmoker_neutral_data_sorted[,1]>0 & v3v5_nonsmoker_neutral_data_sorted[,3]>0))
notshared=length(which(v3v5_nonsmoker_neutral_data_sorted[,1]>0 & v3v5_nonsmoker_neutral_data_sorted[,3]==0))
notshared.ind <- which(v3v5_nonsmoker_neutral_data_sorted[,1]>0 & v3v5_nonsmoker_neutral_data_sorted[,3]==0)

# Make a list of OTUs unique to the target community
uniqueToTarget <- v3v5_nonsmoker_neutral_data_sorted[notshared.ind,]
if(nrow(uniqueToTarget)>0){
uniqueSeq <- matrix(nrow=nrow(uniqueToTarget),ncol=1)
for(i in 1:nrow(uniqueToTarget)){
  
  #EnvSelForSeq[i,1] <- colnames(rS)[environmental_matrix[i,5]+4]
  uniqueSeq[i,1] <- colnames(targetv3v5nonsmoker)[uniqueToTarget[i,5]]
}
uniquedat <- cbind(uniqueToTarget,uniqueSeq)
TaxonomyuniqueSeq <- matrix(nrow=nrow(uniqueToTarget),ncol=1)
for(i in 1:nrow(TaxonomyuniqueSeq)){
  
  searchTerm <- as.character(uniquedat[i,9])
  searchInd <- which(taxonomyFile==searchTerm)
  TaxonomyuniqueSeq[i,1] <- taxonomyFile[searchInd,3]
}

uniquedat2 <- cbind(uniquedat,TaxonomyuniqueSeq)
write.table(uniquedat2,file=paste("Unique", as.character(ID), "txt", sep = "."),sep = "\t", row.names=FALSE,col.names=file.col.names)
}

# Retrieve only the shared OTUs
onlyshared=which(v3v5_nonsmoker_neutral_data_sorted[,1]>0)
v3v5_nonsmoker_neutral_data_final=subset(v3v5_nonsmoker_neutral_data_sorted[onlyshared,])

col=which(v3v5_nonsmoker_neutral_data_final[,4]>0)

v3v5_nonsmoker_neutral_data_final_1=matrix(nrow=length(col),ncol=8)
for (i in 1:length(col)){
	
	v3v5_nonsmoker_neutral_data_final_1[i,1]= v3v5_nonsmoker_neutral_data_final[i,1]
	v3v5_nonsmoker_neutral_data_final_1[i,2]= v3v5_nonsmoker_neutral_data_final[i,2]
	v3v5_nonsmoker_neutral_data_final_1[i,3]= v3v5_nonsmoker_neutral_data_final[i,3]
	v3v5_nonsmoker_neutral_data_final_1[i,4]= v3v5_nonsmoker_neutral_data_final[i,4]
	v3v5_nonsmoker_neutral_data_final_1[i,5]= v3v5_nonsmoker_neutral_data_final[i,5]
	v3v5_nonsmoker_neutral_data_final_1[i,6]= v3v5_nonsmoker_neutral_data_final[i,6]
	v3v5_nonsmoker_neutral_data_final_1[i,7]= v3v5_nonsmoker_neutral_data_final[i,7]
	v3v5_nonsmoker_neutral_data_final_1[i,8]= v3v5_nonsmoker_neutral_data_final[i,8]
}
AllSeq <- matrix(nrow=nrow(v3v5_nonsmoker_neutral_data_final_1),ncol=1)

# Order the data in descending values of the relative abundance of each OTU in the source community
AlldataSorted <- v3v5_nonsmoker_neutral_data_final_1[order(v3v5_nonsmoker_neutral_data_final_1[,2],decreasing=TRUE),]
for(i in 1:nrow(AllSeq)){
  
  
  AllSeq[i,1] <- colnames(targetv3v5nonsmoker)[AlldataSorted[i,5]]
}
Alldat <- cbind(AlldataSorted,AllSeq)
TaxonomyAllSeq <- matrix(nrow=nrow(v3v5_nonsmoker_neutral_data_final_1),ncol=1)
for(i in 1:nrow(TaxonomyAllSeq)){
  
  searchTerm <- as.character(Alldat[i,9])
  searchInd <- which(taxonomyFile==searchTerm)
  TaxonomyAllSeq[i,1] <- taxonomyFile[searchInd,3]
}

Alldat2 <- cbind(Alldat,TaxonomyAllSeq)
write.table(Alldat2,file=paste("Neutral_all_data", as.character(ID), "txt", sep = "."),sep = "\t", row.names=FALSE,col.names=file.col.names)
output.matrix[19,1] <- colSums(v3v5_nonsmoker_neutral_data_final_1)[4]
SharedSeq.ind <- cbind(v3v5_nonsmoker_neutral_data_final_1[,5])
subset.SharedSeq <- cbind(for.shared.seqs[SharedSeq.ind,1])
sharedSeqCount <- colSums(subset.SharedSeq)
target.sharedSeqs <- sum(targetSumSeqs[shared])
Mouth.sharedSeqs <- sum(OralSumSeqs[shared])
obs= v3v5_nonsmoker_neutral_data_final_1
#print(dim(obs))

# Determine the detection limit - basically the lowest abundance in the source community
detlim=obs[nrow(obs),4]
objfun= matrix(nrow=length(Ntm),ncol=2)

# Calculate the expected probability of detection of each OTU in the target community if it was present merely because of neutral processes from the source community
# These probabilities are calculated for all values of Ntm and then the best fit candidate is determined based upon a sum of squares approach
for (j in 1:length(Ntm)){
	
	Ntmloop=Ntm[j]
	
	neutralmatrix= matrix(nrow=nrow(obs),ncol=5)
	
	
		for (i in 1:nrow(obs)){
		neutralmatrix[i,1]=  Ntmloop*obs[i,4]
	}
		for (i in 1:nrow(obs)){
		neutralmatrix[i,2]=  Ntmloop*(1-obs[i,4])
	}
		for (i in 1:nrow(obs)){
		neutralmatrix[i,3]= pbeta(detlim,neutralmatrix[i,1],neutralmatrix[i,2])
	}
	for (i in 1:nrow(obs)){
		neutralmatrix[i,4]= 1-neutralmatrix[i,3]
	}
	for (i in 1:nrow(obs)){
		neutralmatrix[i,5]= (obs[i,1]-neutralmatrix[i,4])^2
	}
	sumcolumns=colSums(neutralmatrix)
	
	
	objfun[j,1]=sumcolumns[5]
	objfun[j,2]=Ntmloop
}


#determine the best minimum objective function
minobj=which.min(objfun[,1])
minobjfun=objfun[minobj[1],1]

#determine the best Ntm value
bestNtm=objfun[minobj[1],2]

#calculate all the parameters for the best neutral model
bestneutralmatrix= matrix(nrow=nrow(obs),ncol=9)
denominator_input1 <- mean(obs[,1])
Forgoodness <- c()


		for (i in 1:nrow(obs)){
		bestneutralmatrix[i,1]=  bestNtm*obs[i,4]
	}
		for (i in 1:nrow(obs)){
		bestneutralmatrix[i,2]=  bestNtm*(1-obs[i,4])
	}
		for (i in 1:nrow(obs)){
		bestneutralmatrix[i,3]= pbeta(detlim,bestneutralmatrix[i,1],bestneutralmatrix[i,2])
	}
	for (i in 1:nrow(obs)){
		bestneutralmatrix[i,4]= 1-bestneutralmatrix[i,3]
	}
	for (i in 1:nrow(obs)){
		bestneutralmatrix[i,5]= (obs[i,1]-bestneutralmatrix[i,4])^2
		Forgoodness[i] <- (obs[i,1]-denominator_input1)^2
	}
		for (i in 1:nrow(obs)){
		bestneutralmatrix[i,6]= (obs[i,5])
		}
		for (i in 1:nrow(obs)){
		bestneutralmatrix[i,7]= (obs[i,6])
		}
		for (i in 1:nrow(obs)){
      # Determine the 95% confidence intervals using a binomial distribution
		bestneutralmatrix[i,8]= binconf(x=nrow(targetv3v5nonsmoker)*bestneutralmatrix[i,4],n=nrow(targetv3v5nonsmoker),alpha=0.05,method="wilson")[2]
		}
			for (i in 1:nrow(obs)){
		bestneutralmatrix[i,9]= binconf(x=nrow(targetv3v5nonsmoker)*bestneutralmatrix[i,4],n=nrow(targetv3v5nonsmoker),alpha=0.05,method="wilson")[3]
		}
		
numerator <- sum(bestneutralmatrix[,5])
denominator <- sum(Forgoodness)
Fit <- 1-(numerator/denominator)
Fit.stdError <- sqrt(numerator/(nrow(obs)))  

actual.freq <- obs[,1]
predicted.freq <- bestneutralmatrix[,4]
range.r2 <- c()
for(iter in 1:100000){
  sim.actual.freq <- sample(actual.freq,replace=TRUE)
  sim.freq <- sample(predicted.freq,replace=TRUE)
  numerator.sim <- sum((sim.actual.freq-sim.freq)^2)
  #range.r2[iter] <- 1-(numerator.sim/denominator)
  #range.r2[iter] <- 1-(numerator.sim/denominator)
  range.r2[iter] <- sqrt((numerator.sim)/(nrow(obs)))
  
}
hist(range.r2)
range.r2 <- sort(range.r2,decreasing=FALSE)
For.p.val <- abs(Fit.stdError-range.r2)
p.val <- which.min(For.p.val)/100000
print("p-value associated with the model is below")
print(p.val)
OTUlist_environmental=c()
	j=1;
	
	for (i in 1:nrow(bestneutralmatrix)){
		j=j
		

		diff=(obs[i,1]/bestneutralmatrix[i,4])
    # If the OTU falls above the upper confidence interval, deem it as over-represented
		if (diff >=1.5 & obs[i,1]>= bestneutralmatrix[i,9]){
			OTUlist_environmental[j]=bestneutralmatrix[i,6]
			j=j+1
			
		}
		
	}

OTUlist_environmental_against=c()
	j=1;
		for (i in 1:nrow(bestneutralmatrix)){
		j=j
		
	
		diff=(obs[i,1]/bestneutralmatrix[i,4])
    # If the OTU falls below the lower confidence interval, deem it as under-represented
		if (diff <=0.75 & obs[i,1]<=bestneutralmatrix[i,8]){
			OTUlist_environmental_against[j]=bestneutralmatrix[i,6]
			j=j+1
			
		}
		
	}
# Determine the Spearman correlation coefficient
# correlcoeff= cor.test(obs[,1],bestneutralmatrix[,4],method="spearman")
# print(correlcoeff)
    "%w/o%" <- function(x, y) x[!x %in% y] #--  x without y
	vf=c(OTUlist_environmental,OTUlist_environmental_against)
	OTUlist_neutral= obs[,5] %w/o% vf
	
	dd_env=which(obs[,5] %in% OTUlist_environmental)
# Make a list of the over-represented OTUs
if(length(dd_env)>0){
environmental_matrix=matrix(nrow=length(dd_env),ncol=8)
for (i in 1:length(dd_env)){
	environmental_matrix[i,1]=obs[dd_env[i],1]
	environmental_matrix[i,2]=obs[dd_env[i],2]
	environmental_matrix[i,3]=obs[dd_env[i],3]
	environmental_matrix[i,4]=obs[dd_env[i],4]
	environmental_matrix[i,5]=obs[dd_env[i],5]
	environmental_matrix[i,6]=obs[dd_env[i],6]
	environmental_matrix[i,7]=obs[dd_env[i],7]
	environmental_matrix[i,8]=obs[dd_env[i],8]
	ForSeq.ind <- cbind(environmental_matrix[,5])
	For.SharedSeq <- cbind(for.shared.seqs[ForSeq.ind,1])
	ForSeqCount <- colSums(For.SharedSeq)
  SourceSeq.ind <- cbind(environmental_matrix[,5])
  Source.SharedSeq <- cbind(Source.shared.seqs[SourceSeq.ind,1])
  SourceForSeqCount <- colSums(Source.SharedSeq)
  
}
output.matrix[21,1] <- colSums(environmental_matrix)[4]
EnvSelForSeq <- matrix(nrow=nrow(environmental_matrix),ncol=1)
environmental_matrix_sorted= environmental_matrix[order(environmental_matrix[,2],decreasing=TRUE),]
for(i in 1:nrow(EnvSelForSeq)){
  
  
  EnvSelForSeq[i,1] <- colnames(targetv3v5nonsmoker)[environmental_matrix_sorted[i,5]]
}
envmat <- cbind(environmental_matrix_sorted,EnvSelForSeq)
TaxonomyForSeq <- matrix(nrow=nrow(envmat),ncol=1)
for(i in 1:nrow(TaxonomyForSeq)){
  
  searchTerm <- as.character(envmat[i,9])
  searchInd <- which(taxonomyFile==searchTerm)
  TaxonomyForSeq[i,1] <- taxonomyFile[searchInd,3]
}

envmat2 <- cbind(envmat,TaxonomyForSeq)
write.table(envmat2,file=paste("Environmental_sel_for", as.character(ID), "txt", sep = "."),sep = "\t", row.names=FALSE,col.names=file.col.names)
}	


# Make a list of the under-represented OTUs

dd_against=which(obs[,5] %in% OTUlist_environmental_against)		

if(length(dd_against)>0){
environmental_against_matrix=matrix(nrow=length(dd_against),ncol=8)
for (i in 1:length(dd_against)){
	environmental_against_matrix[i,1]=obs[dd_against[i],1]
	environmental_against_matrix[i,2]=obs[dd_against[i],2]
	environmental_against_matrix[i,3]=obs[dd_against[i],3]
	environmental_against_matrix[i,4]=obs[dd_against[i],4]
	environmental_against_matrix[i,5]=obs[dd_against[i],5]
	environmental_against_matrix[i,6]=obs[dd_against[i],6]
	environmental_against_matrix[i,7]=obs[dd_against[i],7]
	environmental_against_matrix[i,8]=obs[dd_against[i],8]
	AgainstSeq.ind <- cbind(environmental_against_matrix[,5])
	Against.SharedSeq <- cbind(for.shared.seqs[AgainstSeq.ind,1])
	AgainstSeqCount <- colSums(Against.SharedSeq)
	SourceAgainstSeq.ind <- cbind(environmental_against_matrix[,5])
	SourceAgainst.SharedSeq <- cbind(Source.shared.seqs[SourceAgainstSeq.ind,1])
	SourceAgainstSeqCount <- colSums(SourceAgainst.SharedSeq)
 
}
if(length(dd_against)>1){
environmental_against_matrix_sorted= environmental_against_matrix[order(environmental_against_matrix[,2],decreasing=FALSE),]
}
else{
  environmental_against_matrix_sorted= environmental_against_matrix
}
EnvSelAgainstSeq <- matrix(nrow=nrow(environmental_against_matrix),ncol=1)
for(i in 1:nrow(EnvSelAgainstSeq)){
  
 
  EnvSelAgainstSeq[i,1] <- colnames(targetv3v5nonsmoker)[environmental_against_matrix_sorted[i,5]]
}
envagmat <- cbind(environmental_against_matrix_sorted,EnvSelAgainstSeq)

TaxonomyAgSeq <- matrix(nrow=nrow(envagmat),ncol=1)
for(i in 1:nrow(TaxonomyAgSeq)){
  
  searchTerm <- as.character(envagmat[i,9])
  searchInd <- which(taxonomyFile==searchTerm)
  TaxonomyAgSeq[i,1] <- taxonomyFile[searchInd,3]
}

envagmat2 <- cbind(envagmat,TaxonomyAgSeq)


output.matrix[22,1] <- colSums(environmental_against_matrix)[4]
 write.table(envagmat2,file=paste("Environmental_sel_against", as.character(ID), "txt", sep = "."),sep = "\t", row.names=FALSE,col.names=file.col.names)
}
# Make a list of the neutrally-distributed OTUs
dd_neut=which(obs[,5] %in% OTUlist_neutral)
neutral_matrix=matrix(nrow=length(dd_neut),ncol=8)
for (i in 1:length(dd_neut)){
	neutral_matrix[i,1]=obs[dd_neut[i],1]
	neutral_matrix[i,2]=obs[dd_neut[i],2]
	neutral_matrix[i,3]=obs[dd_neut[i],3]
	neutral_matrix[i,4]=obs[dd_neut[i],4]
	neutral_matrix[i,5]=obs[dd_neut[i],5]
	neutral_matrix[i,6]=obs[dd_neut[i],6]
	neutral_matrix[i,7]=obs[dd_neut[i],7]
	neutral_matrix[i,8]=obs[dd_neut[i],8]
	NeutralSeq.ind <- cbind(neutral_matrix[,5])
	Neutral.SharedSeq <- cbind(for.shared.seqs[NeutralSeq.ind,1])
	NeutralSeqCount <- colSums(Neutral.SharedSeq)
	SourceNeutralSeq.ind <- cbind(neutral_matrix[,5])
	SourceNeutral.SharedSeq <- cbind(Source.shared.seqs[SourceNeutralSeq.ind,1])
	SourceNeutralSeqCount <- colSums(SourceNeutral.SharedSeq)
}
neutral_matrix_sorted= neutral_matrix[order(neutral_matrix[,2],decreasing=TRUE),]
NeutralSeq <- matrix(nrow=nrow(neutral_matrix),ncol=1)
for(i in 1:nrow(NeutralSeq)){
  

  NeutralSeq[i,1] <- colnames(targetv3v5nonsmoker)[neutral_matrix_sorted[i,5]]
}
neutmat <- cbind(neutral_matrix_sorted,NeutralSeq)

TaxonomyNeutSeq <- matrix(nrow=nrow(neutmat),ncol=1)
for(i in 1:nrow(TaxonomyNeutSeq)){
  
  searchTerm <- as.character(neutmat[i,9])
  searchInd <- which(taxonomyFile==searchTerm)
  TaxonomyNeutSeq[i,1] <- taxonomyFile[searchInd,3]
}

neutmat2 <- cbind(neutmat,TaxonomyNeutSeq)
output.matrix[20,1] <- colSums(neutral_matrix)[4]
write.table(neutmat2,file=paste("Neutral", as.character(ID), "txt", sep = "."),sep = "\t", row.names=FALSE,col.names=file.col.names)

# Make the final plot
if(nrow(uniqueToTarget)>0){
plot(obs[,4]*100,bestneutralmatrix[,4]*100,type="l",col="black",lwd=2,xlab=xlabel,ylab=ylabel,log="x", frame.plot=F,xlim=c(0.001,10)) #xlim=c(0.005,6)
lines(obs[,4]*100,bestneutralmatrix[,8]*100,type="l",col="black",lwd=2,lty=2)
lines(obs[,4]*100,bestneutralmatrix[,9]*100,type="l",col="black",lwd=2,lty=2)
points(jitter(neutral_matrix[,4]*100),neutral_matrix[,1]*100,col="darkgrey",pch=16)
  if(length(dd_against) >0) {points(jitter(environmental_against_matrix[,4]*100),jitter(environmental_against_matrix[,1]*100),col="indianred",pch=16,cex=1.25)}
  if(length(dd_env) >0) {points(jitter(environmental_matrix[,4]*100),jitter(environmental_matrix[,1]*100),col="darkgreen",pch=16,cex=1.25)}
  title(main=c("p-value"=p.val))
}else {
  plot(obs[,4]*100,bestneutralmatrix[,4]*100,type="l",col="black",lwd=2,xlab=xlabel,ylab=ylabel,log="x", frame.plot=F,xlim=c(0.001,10)) #xlim=c(0.005,6)
  lines(obs[,4]*100,bestneutralmatrix[,8]*100,type="l",col="black",lwd=2,lty=2)
  lines(obs[,4]*100,bestneutralmatrix[,9]*100,type="l",col="black",lwd=2,lty=2)
  points(jitter(neutral_matrix[,4]*100),neutral_matrix[,1]*100,col="darkgrey",pch=16)
  if(length(dd_against) >0) {points(jitter(environmental_against_matrix[,4]*100),jitter(environmental_against_matrix[,1]*100),col="indianred",pch=16,cex=1.25)}  
  if(length(dd_env) >0) {points(jitter(environmental_matrix[,4]*100),jitter(environmental_matrix[,1]*100),col="darkgreen",pch=16,cex=1.25)}
  title(main=c("p-value")=p.val))
  
}
output.matrix[1,1] <- Fit.stdError
output.matrix[2,1] <- target
output.matrix[3,1] <- mouth
output.matrix[4,1] <- shared
output.matrix[5,1] <- nrow(neutral_matrix)
if(length(dd_env)>0){
                     output.matrix[6,1] <- nrow(environmental_matrix) 
                     output.matrix[12,1] <-colSums(environmental_matrix)[2]*100
                     output.matrix[17,1] <- ForSeqCount }                     
if(length(dd_against)>0){
output.matrix[7,1] <- nrow(environmental_against_matrix)
output.matrix[13,1] <-colSums(environmental_against_matrix)[2]*100
output.matrix[18,1] <- AgainstSeqCount }

output.matrix[8,1] <- colSums(v3v5_nonsmoker_neutral_data_final_1)[2]*100
output.matrix[9,1] <- colSums(uniqueToTarget)[2]*100
output.matrix[10,1] <- colSums(v3v5_nonsmoker_neutral_data_final_1)[4]*100  
output.matrix[11,1] <-  colSums(neutral_matrix)[2]*100   
output.matrix[14,1] <- target_seqs 
output.matrix[15,1] <- sharedSeqCount
output.matrix[16,1] <- NeutralSeqCount
write.table(file=paste("OutputMatrix",ID,sep="_"),output.matrix,sep="\t")  


TotalSeqsintarget <- sum(targetSumSeqs)
TotalSeqsinMouth <- sum(OralSumSeqs)
shared.colind <- v3v5_nonsmoker_neutral_data_final_1[,5]
SharedSeqsintarget <- sum(targetSumSeqs[shared.colind])
SharedSeqsinMouth <- sum(OralSumSeqs[shared.colind])
neutral.colind <- neutral_matrix[,5]
green.colind <- environmental_matrix[,5]
red.colind <- environmental_against_matrix[,5]
NeutralSeqsintarget <- sum(targetSumSeqs[neutral.colind])
NeutralSeqsinMouth <- sum(OralSumSeqs[neutral.colind])
GreenSeqsintarget <- sum(targetSumSeqs[green.colind])
GreenSeqsinMouth <- sum(OralSumSeqs[green.colind])
RedSeqsintarget <- sum(targetSumSeqs[red.colind])
RedSeqsinMouth <- sum(OralSumSeqs[red.colind])

Another.Output <- matrix(nrow=10,ncol=1)
rownames(Another.Output) <- c("TotalSeqsintarget","TotalSeqsinMouth","SharedSeqsintarget","SharedSeqsinMouth","NeutralSeqsintarget","NeutralSeqsinMouth","GreenSeqsintarget","GreenSeqsinMouth","RedSeqsintarget","RedSeqsinMouth")
Another.Output[1,1] <- TotalSeqsintarget
Another.Output[2,1] <- TotalSeqsinMouth
Another.Output[3,1] <- SharedSeqsintarget
Another.Output[4,1] <- SharedSeqsinMouth
Another.Output[5,1] <- NeutralSeqsintarget
Another.Output[6,1] <- NeutralSeqsinMouth
Another.Output[7,1] <- GreenSeqsintarget
Another.Output[8,1] <- GreenSeqsinMouth
Another.Output[9,1] <- RedSeqsintarget
Another.Output[10,1] <- RedSeqsinMouth

write.table(file=paste("AnotherOutputMatrix",ID,sep="_"),Another.Output,sep="\t") 


