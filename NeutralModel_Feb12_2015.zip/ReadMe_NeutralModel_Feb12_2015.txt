This code has been run in RStudio Version 0.97.336

When running with other data:
1. Change input in Line 11 to your OTU by sequence count matrix
2. Change input in Line 14 to your OTU classification file
3. Change input in Line 17 to the total number of OTUs detected overall
4. Change the name of the target and source communities in Lines 20 and 21
5. Change the input in lines 52 and 58 to the row numbers corresponding to the source and target communities

In this code, the fitting parameter Ntm is set to vary from 1 to 100 (Line #44). After running the script
make sure that your best fit Ntm falls within this range. If not, then increase the range of Ntm
till the best fit Ntm falls within that range. To facilitate computations, typically best to start with a
coarse step and then iteratively keep narrowing this down. 

The following files are created upon successful execution of the code:

1. Unique.(Source)- OralWashv35_(Target)- Lungsv35.txt 
A list of OTUs unique to the target - the detection frequency and relative abundance
in both source and target communities is provided. The standard error is also calculated.
The numbers in the column "Col_Ind" and "OTU#" are for computational purposes only and can
be disregarded. 

2. Neutral_all_data.(Source)- OralWashv35_(Target)- Lungsv35.txt 
A list of all OTUs that are shared between the source and target community - these 
are the ones that go into the model calculations.

3. Neutral.(Source)- OralWashv35_(Target)- Lungsv35.txt
A list of neutrally-distributed OTUs

4. Environmental_sel_for.(Source)- OralWashv35_(Target)- Lungsv35.txt
A list of OTUs over-represented in the target community

5. Environmental_sel_against.(Source)- OralWashv35_(Target)- Lungsv35.txt
A list of OTUs under-represented in the target community

6. OutputMatrix_(Source)- OralWashv35_(Target)- Lungsv35 AND AnotherOutputMatrix_(Source)- OralWashv35_(Target)- Lungsv35
Compilation of various data such as cumulative relative abundance of neutrally-distributed OTUs

7. The p-value associated with the neutral model will be printed on the screen and above the figure.


